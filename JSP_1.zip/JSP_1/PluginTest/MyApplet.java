//MyApplet.java
import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;

public class MyApplet extends Applet
{
	String firstName, lastName;
	public void init()
	{
		firstName=getParameter("firstName");
		lastName=getParameter("lastName");
	}
	public void paint(Graphics g)
	{
		setBackground(Color.CYAN);
		g.setColor(Color.YELLOW);
		g.fillOval(100,120,300,100);
		String fullName=firstName+" "+lastName;
		g.setColor(Color.RED);
		Font f=new Font("Helvitica", Font.BOLD,28);
		g.setFont(f);
		g.drawString(fullName,140,160);
	}
}