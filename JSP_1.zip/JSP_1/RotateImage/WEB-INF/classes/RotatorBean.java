//RotatorBean.java
package p1;
public class RotatorBean
{
String name;
String images[]={"1.jpg","2.jpg","3.jpg","4.jpg","5.jpg"};
int index=0;
public String getName()
{
name=images[index];
return name;
}
public void nextIndex()
{
index=(index+1)%images.length;
}
}