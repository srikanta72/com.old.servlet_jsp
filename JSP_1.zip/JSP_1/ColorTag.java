public class ColorTag extends SimpleTagSupport
{
	public void doTag() throws JspException, IOException
	{
		PageContext pageContext= (PageContext)getJspContext();
		JspWriter out= pageContext.getOut();
		JspFragment body= getJspBody();
		StringWriter sw= new StringWriter();
		body.invoke(sw);
		out.println("<font> color=green >"+sw+ " </font>");
	}
}
