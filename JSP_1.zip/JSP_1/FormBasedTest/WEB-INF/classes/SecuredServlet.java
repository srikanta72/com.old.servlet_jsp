//SecuredServlet.java
import javax.servlet.*;
import java.io.*;
public class SecuredServlet extends GenericServlet
{
	public void service(ServletRequest request, ServletResponse response)throws IOException, ServletException
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("This is a Response from Secured Servlet");
		out.close();
	}
}
